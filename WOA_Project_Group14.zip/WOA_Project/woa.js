/* =========================================================
   WOA Drone Path Optimizer — woa.js
   Whale Optimization Algorithm — JavaScript Implementation
   NSUT · Group 14 · COCSC303
   =========================================================

   ALGORITHM OVERVIEW:
   - Each "whale" = one candidate drone route (permutation of waypoints)
   - Fitness = total Euclidean path distance (lower = better)
   - Three WOA behaviors:
       1. Exploitation  — move toward best whale (|A| < 1, p < 0.5)
       2. Exploration   — move toward random whale (|A| >= 1, p < 0.5)
       3. Spiral/Bubble — random swap around best (p >= 0.5)
   - Local Search — hill climbing every 3 iterations
   - Time  Complexity: O(N × M × T)
   - Space Complexity: O(N × M)
*/

"use strict";

/* =========================================================
   CANVAS SETUP
   ========================================================= */
const CM   = document.getElementById("c-map");
const CG   = document.getElementById("c-graph");
const ctxM = CM.getContext("2d");
const ctxG = CG.getContext("2d");
const DPR  = window.devicePixelRatio || 1;

function resizeCanvases() {
  [CM, CG].forEach(c => {
    const w = c.parentElement.clientWidth;
    c.style.width  = w + "px";
    c.style.height = "320px";
    c.width  = w * DPR;
    c.height = 320 * DPR;
    c.getContext("2d").setTransform(DPR, 0, 0, DPR, 0, 0);
  });
}

/* =========================================================
   SLIDER WIRING
   ========================================================= */
function wireSlider(sliderId, outId, formatter) {
  const slider = document.getElementById(sliderId);
  const output = document.getElementById(outId);
  output.textContent = formatter ? formatter(+slider.value) : slider.value;
  slider.addEventListener("input", () => {
    output.textContent = formatter ? formatter(+slider.value) : slider.value;
  });
}

wireSlider("sl-pts", "v-pts");
wireSlider("sl-wh",  "v-wh");
wireSlider("sl-it",  "v-it");
wireSlider("sl-sp",  "v-sp", v => v + "ms");

/* =========================================================
   STATE VARIABLES
   ========================================================= */
let points      = [];    // array of {x, y} waypoints (0..1 range)
let whales      = [];    // array of {path: [], fitness: number}
let bestWhale   = null;  // current global best {path, fitness}
let iteration   = 0;
let maxIter     = 20;
let convHistory = [];    // [{i, d, local}] convergence data
let localPoints = [];    // iterations where local search fired
let running     = false;
let animTimer   = null;
let initDist    = 0;     // distance at start (for improvement %)
let logCount    = 0;

/* =========================================================
   MATH HELPERS
   ========================================================= */

/** Random float between a and b */
function rnd(a, b) {
  return a + Math.random() * (b - a);
}

/** Euclidean distance between two waypoints */
function euclidean(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/**
 * FITNESS FUNCTION
 * Total closed-loop Euclidean distance of a path.
 * path = array of indices into points[]
 */
function pathDistance(path) {
  let total = 0;
  for (let i = 0; i < path.length - 1; i++) {
    total += euclidean(points[path[i]], points[path[i + 1]]);
  }
  // Close the loop back to start
  total += euclidean(points[path[path.length - 1]], points[path[0]]);
  return total;
}

/**
 * POSITION UPDATE OPERATOR (discrete version of WOA vector math)
 * Swaps two random indices in the path — simulates moving in solution space.
 */
function randomSwap(path) {
  const newPath = [...path];
  let i = Math.floor(Math.random() * newPath.length);
  let j;
  do { j = Math.floor(Math.random() * newPath.length); } while (j === i);
  [newPath[i], newPath[j]] = [newPath[j], newPath[i]];
  return newPath;
}

/** Fisher-Yates shuffle */
function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * LOCAL SEARCH — hill climbing with random swaps
 * Runs 6 swap attempts on the best solution; keeps improvements.
 * Triggered every 3rd iteration (modification to standard WOA).
 */
function localSearch(whale) {
  let improved = { path: [...whale.path], fitness: whale.fitness };
  for (let k = 0; k < 6; k++) {
    const newPath    = randomSwap(improved.path);
    const newFitness = pathDistance(newPath);
    if (newFitness < improved.fitness) {
      improved = { path: newPath, fitness: newFitness };
    }
  }
  return improved;
}

/* =========================================================
   INITIALIZATION
   ========================================================= */

/** Generate brand-new random waypoints and reinitialize */
function newPoints() {
  stopRun();
  const n = +document.getElementById("sl-pts").value;
  points = [];
  for (let i = 0; i < n; i++) {
    points.push({ x: rnd(0.07, 0.93), y: rnd(0.07, 0.93) });
  }
  resetAll();
}

/** Initialize whale population with random paths */
function initWhales() {
  const n    = +document.getElementById("sl-wh").value;
  maxIter    = +document.getElementById("sl-it").value;
  const base = [...Array(points.length).keys()]; // [0, 1, 2, ..., M-1]

  whales = [];
  for (let i = 0; i < n; i++) {
    const path    = shuffle([...base]);
    const fitness = pathDistance(path);
    whales.push({ path, fitness });
  }

  // Find best initial whale
  bestWhale = whales.reduce((best, w) => w.fitness < best.fitness ? w : best);
  bestWhale = { path: [...bestWhale.path], fitness: bestWhale.fitness };

  initDist    = bestWhale.fitness;
  iteration   = 0;
  convHistory = [{ i: 0, d: bestWhale.fitness, local: false }];
  localPoints = [];

  // Update info panel
  document.getElementById("i-wh").textContent   = n;
  document.getElementById("i-pts").textContent  = points.length;
  document.getElementById("i-init").textContent = bestWhale.fitness.toFixed(1);
  document.getElementById("s-iter").textContent = "0 / " + maxIter;
  updateStats(2.0, false, false);
}

/* =========================================================
   WOA MAIN STEP  —  one full iteration
   ========================================================= */
function woaStep() {
  iteration++;

  // Control parameter: decreases linearly from 2 → 0
  const a = 2.0 - iteration * (2.0 / maxIter);

  let anyImproved = false;
  const phaseCount = { exploit: 0, explore: 0, spiral: 0 };

  /* ── Update each whale ── */
  for (let i = 0; i < whales.length; i++) {
    const r = Math.random();
    const A = 2 * a * r - a;   // encircling coefficient
    const p = Math.random();   // behavior selector

    let candidate;

    if (p < 0.5) {
      if (Math.abs(A) < 1) {
        /* ── EXPLOITATION: encircle the best whale ──
           Move toward the current best solution */
        candidate = { path: randomSwap(bestWhale.path) };
        phaseCount.exploit++;
      } else {
        /* ── EXPLORATION: random whale ──
           Search around a randomly selected whale */
        const randIdx = Math.floor(Math.random() * whales.length);
        candidate = { path: randomSwap(whales[randIdx].path) };
        phaseCount.explore++;
      }
    } else {
      /* ── SPIRAL / BUBBLE-NET ATTACK ──
         Spiral update around best whale */
      candidate = { path: randomSwap(bestWhale.path) };
      phaseCount.spiral++;
    }

    candidate.fitness = pathDistance(candidate.path);

    // Greedy selection — keep candidate only if it improves
    if (candidate.fitness < whales[i].fitness) {
      whales[i] = candidate;
    }

    // Update global best
    if (whales[i].fitness < bestWhale.fitness) {
      bestWhale   = { path: [...whales[i].path], fitness: whales[i].fitness };
      anyImproved = true;
    }
  }

  // Determine dominant phase this iteration
  const dom = Object.entries(phaseCount).sort((x, y) => y[1] - x[1])[0][0];
  setPhaseIndicator(dom);

  /* ── LOCAL SEARCH every 3rd iteration ── */
  let localUsed = false;
  if (iteration % 3 === 0) {
    const ls = localSearch(bestWhale);
    if (ls.fitness < bestWhale.fitness) {
      bestWhale   = ls;
      anyImproved = true;
      localUsed   = true;
    }
    setPhaseIndicator("local");
    localPoints.push(iteration);
  }

  // Record convergence
  convHistory.push({ i: iteration, d: bestWhale.fitness, local: localUsed });

  // Redraw visuals
  updateStats(a, anyImproved, localUsed);
  drawMap();
  drawGraph();

  // Log output (mirrors C++ cout)
  const impPct   = ((initDist - bestWhale.fitness) / initDist * 100).toFixed(1);
  const logClass = localUsed ? "local" : (anyImproved ? "improved" : "iter");
  addLog(
    `iter ${String(iteration).padStart(2, "0")}  |  ` +
    `a=${a.toFixed(3)}  |  ` +
    `dist=${bestWhale.fitness.toFixed(2)}  |  ` +
    `imp=${impPct}%` +
    (localUsed ? "  [local search]" : ""),
    logClass
  );

  // Check termination
  if (iteration >= maxIter) {
    stopRun();
    document.getElementById("s-status").textContent   = "Done";
    document.getElementById("s-status").style.color   = "#10b981";
    document.getElementById("map-badge").textContent  = "Optimal path found";
    addLog(
      `── Finished! Best dist: ${bestWhale.fitness.toFixed(2)}  Total improvement: ${impPct}% ──`,
      "done"
    );
    setPhaseIndicator("");
  }
}

/* =========================================================
   UI UPDATE FUNCTIONS
   ========================================================= */

function updateStats(a, improved, local) {
  if (!bestWhale) return;
  document.getElementById("s-dist").textContent = bestWhale.fitness.toFixed(1);
  document.getElementById("s-iter").textContent = iteration + " / " + maxIter;
  const imp = initDist > 0
    ? ((initDist - bestWhale.fitness) / initDist * 100).toFixed(1) + "%"
    : "—";
  document.getElementById("s-imp").textContent  = imp;
  document.getElementById("s-a").textContent    = a != null ? a.toFixed(3) : "2.000";
  document.getElementById("i-best").textContent = bestWhale.fitness.toFixed(1);
  document.getElementById("s-phase").textContent = local
    ? "Local search active"
    : (improved ? "Improved!" : "");
}

function setPhaseIndicator(name) {
  ["exploit", "explore", "spiral", "local"].forEach(p => {
    const el = document.getElementById("ph-" + p);
    el.className = "phase-item" + (p === name ? " active-" + p : "");
  });
}

function addLog(message, cls) {
  const container = document.getElementById("log");
  const line      = document.createElement("div");
  line.className  = "log-line " + (cls || "");
  line.textContent = message;
  container.appendChild(line);
  // Auto-scroll to bottom
  container.parentElement.scrollTop = 999999;
  logCount++;
  document.getElementById("log-count").textContent = logCount + " lines";
}

function clearLog() {
  document.getElementById("log").innerHTML = "";
  logCount = 0;
  document.getElementById("log-count").textContent = "0 lines";
}

/* =========================================================
   RUN CONTROLS
   ========================================================= */

function toggleRun() {
  if (running) { stopRun(); return; }
  if (points.length === 0) newPoints();
  if (iteration === 0) initWhales();

  running = true;
  const btn      = document.getElementById("btn-run");
  btn.textContent = "■ Stop";
  btn.classList.add("stop-mode");
  document.getElementById("btn-step").disabled         = true;
  document.getElementById("s-status").textContent      = "Running";
  document.getElementById("s-status").style.color      = "#3b82f6";
  document.getElementById("map-badge").textContent     = "Optimizing...";

  function tick() {
    woaStep();
    if (running && iteration < maxIter) {
      const speed = +document.getElementById("sl-sp").value;
      animTimer   = setTimeout(tick, speed);
    }
  }
  tick();
}

function stopRun() {
  running = false;
  clearTimeout(animTimer);
  const btn       = document.getElementById("btn-run");
  btn.textContent = "▶ Run";
  btn.classList.remove("stop-mode");
  document.getElementById("btn-step").disabled = (iteration >= maxIter);
  if (iteration > 0 && iteration < maxIter) {
    document.getElementById("s-status").textContent = "Paused";
    document.getElementById("s-status").style.color = "#f59e0b";
  }
}

function resetAll() {
  stopRun();
  if (points.length === 0) { newPoints(); return; }
  initWhales();
  clearLog();
  convHistory = [{ i: 0, d: bestWhale.fitness, local: false }];

  document.getElementById("s-status").textContent    = "Ready";
  document.getElementById("s-status").style.color    = "#64748b";
  document.getElementById("s-a").textContent         = "2.000";
  document.getElementById("s-imp").textContent       = "—";
  document.getElementById("map-badge").textContent   = "Initialized";
  document.getElementById("btn-step").disabled       = false;
  setPhaseIndicator("");

  drawMap();
  drawGraph();

  addLog("Initialized — " + points.length + " waypoints, " + whales.length + " whales, " + maxIter + " max iterations", "init");
  addLog("Initial best distance: " + bestWhale.fitness.toFixed(2), "init");
}

function stepOnce() {
  if (points.length === 0) newPoints();
  if (iteration === 0) initWhales();
  if (iteration >= maxIter) return;
  woaStep();
  document.getElementById("btn-step").disabled = (iteration >= maxIter);
}

/* =========================================================
   DRAW — MAP CANVAS
   ========================================================= */
function drawMap() {
  const W = CM.width / DPR;
  const H = CM.height / DPR;
  ctxM.clearRect(0, 0, W, H);

  const PAD = 28;
  const toPixel = pt => ({
    x: PAD + pt.x * (W - PAD * 2),
    y: PAD + pt.y * (H - PAD * 2)
  });

  // Background grid
  ctxM.strokeStyle = "rgba(59,130,246,0.06)";
  ctxM.lineWidth   = 0.5;
  for (let x = 0; x < W; x += 40) {
    ctxM.beginPath(); ctxM.moveTo(x, 0); ctxM.lineTo(x, H); ctxM.stroke();
  }
  for (let y = 0; y < H; y += 40) {
    ctxM.beginPath(); ctxM.moveTo(0, y); ctxM.lineTo(W, y); ctxM.stroke();
  }

  if (!bestWhale || !points.length) return;

  /* ── All whale paths (faint) ── */
  whales.forEach(w => {
    ctxM.beginPath();
    const s = toPixel(points[w.path[0]]);
    ctxM.moveTo(s.x, s.y);
    w.path.forEach(idx => {
      const p = toPixel(points[idx]);
      ctxM.lineTo(p.x, p.y);
    });
    ctxM.lineTo(s.x, s.y);
    ctxM.strokeStyle = "rgba(99,179,237,0.07)";
    ctxM.lineWidth   = 1;
    ctxM.stroke();
  });

  /* ── Best path glow (wide soft layer) ── */
  const path = bestWhale.path;
  const s0   = toPixel(points[path[0]]);

  ctxM.beginPath();
  ctxM.moveTo(s0.x, s0.y);
  path.forEach(idx => {
    const p = toPixel(points[idx]);
    ctxM.lineTo(p.x, p.y);
  });
  ctxM.lineTo(s0.x, s0.y);
  ctxM.strokeStyle = "rgba(16,185,129,0.18)";
  ctxM.lineWidth   = 7;
  ctxM.stroke();

  /* ── Best path sharp line ── */
  ctxM.beginPath();
  ctxM.moveTo(s0.x, s0.y);
  path.forEach(idx => {
    const p = toPixel(points[idx]);
    ctxM.lineTo(p.x, p.y);
  });
  ctxM.lineTo(s0.x, s0.y);
  ctxM.strokeStyle = "#10b981";
  ctxM.lineWidth   = 1.8;
  ctxM.stroke();

  /* ── Direction arrows on path ── */
  for (let i = 0; i < path.length; i++) {
    const a   = toPixel(points[path[i]]);
    const b   = toPixel(points[path[(i + 1) % path.length]]);
    const mx  = (a.x + b.x) / 2;
    const my  = (a.y + b.y) / 2;
    const ang = Math.atan2(b.y - a.y, b.x - a.x);
    ctxM.save();
    ctxM.translate(mx, my);
    ctxM.rotate(ang);
    ctxM.beginPath();
    ctxM.moveTo(5, 0);
    ctxM.lineTo(-5, -4);
    ctxM.lineTo(-5, 4);
    ctxM.closePath();
    ctxM.fillStyle = "rgba(16,185,129,0.6)";
    ctxM.fill();
    ctxM.restore();
  }

  /* ── Waypoint nodes ── */
  points.forEach((pt, i) => {
    const p       = toPixel(pt);
    const isDepot = bestWhale.path[0] === i;
    const r       = isDepot ? 11 : 7;

    // Outer glow ring
    ctxM.beginPath();
    ctxM.arc(p.x, p.y, r + 4, 0, Math.PI * 2);
    ctxM.fillStyle = isDepot
      ? "rgba(16,185,129,0.15)"
      : "rgba(59,130,246,0.10)";
    ctxM.fill();

    // Node circle
    ctxM.beginPath();
    ctxM.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctxM.fillStyle   = isDepot ? "#10b981" : "#3b82f6";
    ctxM.fill();
    ctxM.strokeStyle = isDepot ? "#065f46" : "#1e3a8a";
    ctxM.lineWidth   = 1.5;
    ctxM.stroke();

    // Node number label
    ctxM.fillStyle    = "#fff";
    ctxM.font         = (isDepot ? "700 " : "600 ") + "9px 'JetBrains Mono', monospace";
    ctxM.textAlign    = "center";
    ctxM.textBaseline = "middle";
    ctxM.fillText(i + 1, p.x, p.y);
  });

  // Info label bottom-left
  ctxM.fillStyle    = "#64748b";
  ctxM.font         = "11px 'JetBrains Mono', monospace";
  ctxM.textAlign    = "left";
  ctxM.textBaseline = "alphabetic";
  ctxM.fillText("dist: " + bestWhale.fitness.toFixed(1) + "  |  iter: " + iteration, 8, H - 6);
}

/* =========================================================
   DRAW — CONVERGENCE GRAPH CANVAS
   ========================================================= */
function drawGraph() {
  const W = CG.width / DPR;
  const H = CG.height / DPR;
  ctxG.clearRect(0, 0, W, H);

  if (convHistory.length < 2) return;

  const PAD  = { l: 52, r: 20, t: 20, b: 38 };
  const gW   = W - PAD.l - PAD.r;
  const gH   = H - PAD.t  - PAD.b;

  const allD   = convHistory.map(h => h.d);
  const minD   = Math.min(...allD);
  const maxD   = Math.max(...allD);
  const rangeD = maxD - minD || 1;

  const gx = i => PAD.l + (i / maxIter) * gW;
  const gy = d => PAD.t + gH - ((d - minD) / rangeD) * gH;

  /* ── Grid lines ── */
  ctxG.strokeStyle = "rgba(59,130,246,0.08)";
  ctxG.lineWidth   = 0.5;

  // Horizontal grid + Y labels
  for (let i = 0; i <= 4; i++) {
    const y = PAD.t + i * gH / 4;
    ctxG.beginPath(); ctxG.moveTo(PAD.l, y); ctxG.lineTo(PAD.l + gW, y); ctxG.stroke();
    const val = maxD - i * (rangeD / 4);
    ctxG.fillStyle    = "#64748b";
    ctxG.font         = "10px 'JetBrains Mono', monospace";
    ctxG.textAlign    = "right";
    ctxG.textBaseline = "middle";
    ctxG.fillText(val.toFixed(0), PAD.l - 6, y);
  }

  // Vertical grid + X labels
  for (let i = 0; i <= 5; i++) {
    const x = PAD.l + i * gW / 5;
    ctxG.beginPath(); ctxG.moveTo(x, PAD.t); ctxG.lineTo(x, PAD.t + gH); ctxG.stroke();
    ctxG.fillStyle    = "#64748b";
    ctxG.font         = "10px 'JetBrains Mono', monospace";
    ctxG.textAlign    = "center";
    ctxG.textBaseline = "top";
    ctxG.fillText(Math.round(i * maxIter / 5), x, PAD.t + gH + 6);
  }

  /* ── Axes ── */
  ctxG.strokeStyle = "rgba(99,179,237,0.3)";
  ctxG.lineWidth   = 1;
  ctxG.beginPath();
  ctxG.moveTo(PAD.l, PAD.t);
  ctxG.lineTo(PAD.l, PAD.t + gH);
  ctxG.lineTo(PAD.l + gW, PAD.t + gH);
  ctxG.stroke();

  /* ── Axis labels ── */
  ctxG.fillStyle = "#64748b";
  ctxG.font      = "11px 'JetBrains Mono', monospace";
  ctxG.textAlign = "center";
  ctxG.fillText("Iteration →", PAD.l + gW / 2, H - 4);
  ctxG.save();
  ctxG.rotate(-Math.PI / 2);
  ctxG.fillText("Distance", -(PAD.t + gH / 2), 14);
  ctxG.restore();

  /* ── Area fill under line ── */
  ctxG.beginPath();
  ctxG.moveTo(gx(convHistory[0].i), gy(convHistory[0].d));
  convHistory.forEach(h => ctxG.lineTo(gx(h.i), gy(h.d)));
  ctxG.lineTo(gx(convHistory[convHistory.length - 1].i), PAD.t + gH);
  ctxG.lineTo(gx(0), PAD.t + gH);
  ctxG.closePath();
  ctxG.fillStyle = "rgba(16,185,129,0.08)";
  ctxG.fill();

  /* ── Convergence line ── */
  ctxG.beginPath();
  ctxG.moveTo(gx(convHistory[0].i), gy(convHistory[0].d));
  convHistory.forEach(h => ctxG.lineTo(gx(h.i), gy(h.d)));
  ctxG.strokeStyle = "#10b981";
  ctxG.lineWidth   = 2;
  ctxG.stroke();

  /* ── Data points ── */
  convHistory.forEach(h => {
    const x = gx(h.i);
    const y = gy(h.d);

    if (h.local) {
      // Local search point — amber with ring
      ctxG.beginPath();
      ctxG.arc(x, y, 8, 0, Math.PI * 2);
      ctxG.strokeStyle = "rgba(245,158,11,0.35)";
      ctxG.lineWidth   = 1;
      ctxG.stroke();
    }

    ctxG.beginPath();
    ctxG.arc(x, y, h.local ? 5 : 3, 0, Math.PI * 2);
    ctxG.fillStyle = h.local ? "#f59e0b" : "#10b981";
    ctxG.fill();
  });

  /* ── Current best label ── */
  if (convHistory.length > 1) {
    const last = convHistory[convHistory.length - 1];
    ctxG.fillStyle    = "#10b981";
    ctxG.font         = "bold 11px 'JetBrains Mono', monospace";
    ctxG.textAlign    = "left";
    ctxG.textBaseline = "middle";
    ctxG.fillText(last.d.toFixed(1), gx(last.i) + 6, gy(last.d) - 4);
  }
}

/* =========================================================
   STARTUP
   ========================================================= */
window.addEventListener("resize", () => {
  resizeCanvases();
  drawMap();
  drawGraph();
});

resizeCanvases();
newPoints();
